<?PHP
  // verbinding maken met de database
        $dbname = 'lostfound';
        $dbhost = 'localhost';
        $username = 'timdebeer';
        $password = '';
        
        $db_conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $username, $password);
?>
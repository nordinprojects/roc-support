html {
  background:url('https://cdn.wallpapersafari.com/42/90/1P6Nzf.jpg');
}
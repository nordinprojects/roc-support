<!DOCTYPE html>
<?php
include('database2.php');
include('PHPMailer.php');

if(isset($_POST['submit'])){
    
    $DefectKlacht = $_POST['DefectKlacht'];
    $plaats = $_POST['plaats'];
    $locatie = $_POST['locatie'];
    $oorzaak = $_POST['oorzaak'];

    $sql = "INSERT INTO DefectKlacht (DefectKlacht, plaats, locatie, oorzaak) VALUES ('$DefectKlacht','$plaats','$locatie','$oorzaak')";

    if ($db_conn->query($sql) === TRUE) {
        echo "Nieuwe data toegevoegd!";
    } else {
        echo "Bericht gestuurd<br>" . $db_conn->error;
    }
}
?>

?>
<html>
    <head>
         <title>Defect</title>
         <a href="index1.php">Home</a>
    </head>
     <body>
      <form method="POST">
            Uw Defect/klacht:
            <input type="text" name="DefectKlacht" placeholder ="Defectklacht">
            <br>
            Uw plaats:
            <input type="text" name="plaats" placeholder ="plaats">
            <br>
            Uw locatie:
            <input type="text" name="locatie" placeholder ="locatie">
            <br>
            oorzaak:
            <input type="text" name="oorzaak" placeholder ="oorzaak">
            <br>
            <input type="submit" name="submit" value="Versturen">
        </form>
  	</body>
</html>
<!DOCTYPE html>
<?php
 include('database2.php');
?>
<html>
    <head> 
    <h1>Geef u Melding</h1>
         <title>Meldingregistratie</title>
          <a href="Defect.php">Defect</a>
          <a href="Evenement.php">Evenement</a>
    </head>
     <body>
 	
 	
 	
  	</body>
</html>  
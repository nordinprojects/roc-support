
<?php
include('database2.php');
if(isset($_POST['submit'])){
require "PHPMailerAutoload.php";

$mail = new PHPMailer;

$mail->host="smtp.gmail.com";
$mail->port=587;
$mail->SMTPAuth=true;
$mailS->SMTPSecure="tls";
$mail->Username="joelamarh@gmail.com";
$mail->Password="";
$mail->SetFrom($_POST["v_EVE"],($_POST["w_Reden"],($_POST["email"])));
$mail->AddAdress("joel.boy@live.nl");
$mail->addReplyTo($_POST["v_EVE"],($_POST["w_Reden"],($_POST["email"])));

$mail->isHTML=(true);

$mail->v_EVE="Form Submission: ".$_POST["v_EVE"];
$mail->Body="<h1 align=center>Reden :".$_POST["email"]."<br>Email: ".$_POST["v_EVE"].
"<br>Message: ".$_POST["w_Reden "]."</h1>";

if(!$mail->send()){
    $result="Something went wrong. Please try agian.";
}
else{
    $result="Thanks"; 
}

?>

<?php
include('database2.php');
if(isset($_POST['submit'])){
    
    $EVE = $_POST['v_EVE'];
    $Plaats = $_POST['v_Plaats'];
    $Datum = $_POST['w_Datum'];
    $Reden = $_POST['w_Reden'];
    $Naam = $_POST['Naam'];
    $email = $_POST['email'];
    $studentnummer = $_POST['studentnummer'];
    


    $sql = "INSERT INTO Evenementen (`Evenement`, `Plaats`, `Datum`, `Reden`, `Naam`, `email`, `studentnummer`) VALUES ('$EVE','$Plaats','$Datum','$Reden','$Naam','$email','$studentnummer')";

    if ($db_conn->query($sql) === TRUE) {
        echo "Nieuwe data toegevoegd!";
    } else {
        echo "Bericht gestuurd<br>" . $db_conn->error;
    }
}
?>

<html>
    <head>
         <title>Evenementen</title>
         
    </head>
     <body>
         <form method="POST" class="evenement">
            Naam:
            <input type="text" name="Naam" class="form-control" placeholder="Naam">
            <br>
            studentnummer:
            <input type="text" name="studentnummer" class="form-control" placeholder="studentnummer">
            <br>
            email:
            <input type="text" name="email" class="form-control" placeholder="email">
            <br>
 	        Uw Evenement:
            <input type="text" name="v_EVE" class="form-control" placeholder="Evenement">
            <br>
            Uw plaats:
            <input type="text" name="v_Plaats" class="form-control" placeholder="Plaats">
            <br>
            Uw Datum:
            <input type="Datum" name="w_Datum" class="form-control" placeholder="Datum">
            <br>
            Reden:
            <input type="text" name="w_Reden" class="form-control" placeholder="Reden">
            <br>
            <input type="submit" name="submit" class="btnContact" value="Versturen">
           
        </form>
 	
 	
 	
 	
  	</body>
</html>
